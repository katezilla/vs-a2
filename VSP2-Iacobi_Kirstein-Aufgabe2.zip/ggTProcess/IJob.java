package ggTProcess;

public interface IJob {

}
